import React from 'react';
import './Publicacao.css';


function Publicacao() {
  return (
    <div className="publicacao">
      Pagina de cadastro de uma publicacao
    </div>
  );
}
 
export default Publicacao;
