import React from 'react';
import './Noticies.css';

function Noticies() {
  return (
    <div className="Noticies">
        <h6>Linkedin Notícias</h6>
        <ul>
          <li><h6>Novas Noticias</h6> <p>4h - Noticias mais lidas</p></li>
          <li><h6>Novas Noticias</h6><p>4h - Noticias mais lidas</p></li>
          <li><h6>Novas Noticias</h6><p>4h - Noticias mais lidas</p></li>
          <li><h6>Novas Noticias</h6><p>4h - Noticias mais lidas</p></li>
        </ul>
    </div>
  );
}
 
export default Noticies;
