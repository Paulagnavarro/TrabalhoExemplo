module.exports = {
  dialect: 'mysql',
  host: 'localhost',
  username: 'root',
  port: '8111',
  password: '',
  database: 'linkedinMysqlernClone',
  define: {
    timestamps: true,
    underscored: true,
  },
};